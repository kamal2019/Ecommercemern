import React from 'react'
import "../index.scss"

function About() {
  return (
    <div className='aboutus-text container'>
        <h2 className='about-header'>About Us</h2>
        <p className='about-paragraph'>You can write about your ecommerce here</p>
    </div>
  )
}

export default About